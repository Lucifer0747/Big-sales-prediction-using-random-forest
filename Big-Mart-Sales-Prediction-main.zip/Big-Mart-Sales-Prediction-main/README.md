# Big-Mart-Sales-Prediction

## Big Mart Sales Prediction Using Machine Learning. (Regression Use Case)

![image](https://user-images.githubusercontent.com/69152112/210663574-69abaae8-c776-409c-9202-226e3b7ae136.png)

### Implemented Algorithms are:

#### 1. RandomForest Regression

#### 2. Linear Regression
